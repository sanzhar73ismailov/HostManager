For platform builder(PB) installation, please copy the driver and configurator file to your platform builder by yourself.

For Windows CE5 Driver:
    CE5\Nptpdd.dll
    CE5\NPortINIT.dll

For Windows CE6 Driver:
    CE6\Nptpdd.dll
    CE6\NPortINIT.dll

Configurator:
    NPTcfg.exe
    dsci_wce_x86.dll
    